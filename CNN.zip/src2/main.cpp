#include "main.h"
using namespace std;
int main()
{
    printf("O C B!\n");
     GameRendering game;
     //game.mainLoop();
   return 0;
}
