#include "Train.h"
#include "cuda.h"

std::vector<NeuralNetwork> Train::training(int rounds)
{
    cuInit(0);
    CUresult r;
    CUdevice cuDevice;
    cuDeviceGet(&cuDevice, 0);
    CUcontext cuContext;
    cuCtxCreate(&cuContext, 0, cuDevice);
    CUmodule module;
    cuModuleLoad(&module, "Train.ptx");
    CUfunction trainBirds, mutation;
    cuModuleGetFunction(&trainBirds, module, "TrainBirds");
    cuModuleGetFunction(&mutation, module, "Mutation");

    int threads_block = 1024, blocks_x = UNITY_IN_TRAINING/threads_block;
    int sizeNeuralNet = 54, numberOfNeurons = 9, edgesForNeuron = 6;
    float *arr; // 65kx9x6

    CUdeviceptr arrOfWeights, fitness; // ew stale
    cuMemAllocHost((void**)&arr, UNITY_IN_TRAINING*54*sizeof(float));
    cuMemAlloc(&arrOfWeights, UNITY_IN_TRAINING*54*sizeof(float));
    cuMemAlloc(&fitness, UNITY_IN_TRAINING*sizeof(float));

    for(int l=0; l<20; l++)
    {
        for(int i=0; i<UNITY_IN_TRAINING; i++)
        {
            for(int j=0; j<9; j++)
            {
                for(int k=0; k<6; k++)
                {
                  arr[i*sizeNeuralNet+j*edgesForNeuron+k] = trainNet[i].weights[j][k];
                }
            }
        }

        cuMemcpyHtoD(arrOfWeights, arr, UNITY_IN_TRAINING*54*sizeof(float));
        cuMemcpyHtoD(fitness, fitCoefficients, UNITY_IN_TRAINING*sizeof(float));

        void* argsTB[4] = {&arrOfWeights, &fitness}; // ewentualnie stale
        cuLaunchKernel(trainBirds, UNITY_IN_TRAINING, 1, 1, 1024, 1, 1, 0, 0, argsTB, 0);

        cuMemcpyDtoH(arr, arrOfWeights, UNITY_IN_TRAINING*54*sizeof(float));
        cuMemcpyDtoH(fitCoefficients, fitness, UNITY_IN_TRAINING*sizeof(float));

        std::vector< std::pair<float, int> > coefToSort;
        for(int i=0; i<UNITY_IN_TRAINING; i++) {
            coefToSort.push_back(std::make_pair(fitCoefficients[i], i));
        }
        std::sort(coefToSort.begin(), coefToSort.end());

        std::vector<NeuralNetwork> beasts;
        for(int i=9; i>=0; i--)
          beasts.push_back(trainNet[coefToSort[i].second]);
    }
}

std::vector<int> Train::chooseTenBest() {

}
float Train::fitness_function() {

}
float Train::crossover() {

}
void Train::mutation() {

}
